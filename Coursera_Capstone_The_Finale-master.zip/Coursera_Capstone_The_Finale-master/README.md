# Coursera_Capstone
Capstone Project - Relocation assistand
To view the Jupyter Notebook with functional interactive maps use:
https://nbviewer.jupyter.org/github/JakubVoros/Coursera_Capstone_The_Finale/blob/master/assistant2.ipynb
